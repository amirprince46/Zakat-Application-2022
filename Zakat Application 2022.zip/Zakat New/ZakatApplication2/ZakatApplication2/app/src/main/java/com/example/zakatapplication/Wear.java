package com.example.zakatapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Wear extends AppCompatActivity {

    EditText weightwear, currentwear;
    TextView resulttext;
    String calculation, zakatresult;
    float uruf;
    double totalzakat;

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wear);

        weightwear = findViewById(R.id.weightwear);
        currentwear = findViewById(R.id.currentwear);
        resulttext = findViewById(R.id.result2);

        bottomNavigationView = findViewById(R.id.bottom_navigator);
        bottomNavigationView.setSelectedItemId(R.id.wear);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.dashboard:
                        startActivity(new Intent(getApplicationContext(), Dashboard.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.keep:
                        startActivity(new Intent(getApplicationContext(), Wear.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.wear:
                        return true;
                    case R.id.about:
                        startActivity(new Intent(getApplicationContext(), About.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.info:
                        startActivity(new Intent(getApplicationContext(), Info.class));
                        overridePendingTransition(0, 0);
                        return true;
                }

                return false;
            }
        });
    }

    public void calculatezakat2(View view) {

        if (weightwear.length() == 0) {
            weightwear.setError("Please input gold weight");
        } else if (currentwear.length() == 0) {
            currentwear.setError("Please input current gold value");
        } else {

            String S1 = weightwear.getText().toString();
            String S2 = currentwear.getText().toString();

            float weightvalue = Float.parseFloat(S1);
            float currentvalue = Float.parseFloat(S2);

            float totalvalue = weightvalue * currentvalue;
            float uruf = weightvalue - 200;
            float zakat = uruf * currentvalue;
            double totalzakat = zakat * 0.025;

            TextView et3 = (TextView) findViewById(R.id.output3);
            et3.setText("Total Value:\n" + "RM " + totalvalue);

            TextView et4 = (TextView) findViewById(R.id.output4);
            et4.setText("Zakat Payable\n" + "RM " + zakat);

            if (totalzakat < 0) {
                totalzakat = 0;
                calculation = "Total Zakat:\n" + "RM " + totalzakat;
                resulttext.setText(calculation);

            } else {
                calculation = "Total Zakat:\n" + "RM " + totalzakat;
                resulttext.setText(calculation);
            }
        }
    }
}

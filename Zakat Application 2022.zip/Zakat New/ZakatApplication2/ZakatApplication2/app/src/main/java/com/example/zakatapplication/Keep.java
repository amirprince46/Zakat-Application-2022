package com.example.zakatapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class Keep extends AppCompatActivity {

    EditText weight, current;
    float zakat, totalvalue;
    TextView resulttext;
    String calculation;

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keep);

        weight = findViewById(R.id.weight);
        current = findViewById(R.id.current);
        resulttext = findViewById(R.id.result);


        bottomNavigationView = findViewById(R.id.bottom_navigator);
        bottomNavigationView.setSelectedItemId(R.id.keep);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.dashboard:
                        startActivity(new Intent(getApplicationContext(), Dashboard.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.keep:
                        return true;
                    case R.id.wear:
                        startActivity(new Intent(getApplicationContext(), Wear.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.about:
                        startActivity(new Intent(getApplicationContext(), About.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.info:
                        startActivity(new Intent(getApplicationContext(), Info.class));
                        overridePendingTransition(0, 0);
                        return true;
                }

                return false;
            }
        });
    }

    public void calculatezakat(View view) {

        if (weight.length() == 0) {
            weight.setError("Please input gold weight");
        } else if (current.length() == 0) {
            current.setError("Please input current gold value");
        } else {

            String S1 = weight.getText().toString();
        String S2 = current.getText().toString();

        float weightvalue = Float.parseFloat(S1);
        float currentvalue = Float.parseFloat(S2);

        float totalvalue = weightvalue * currentvalue;
        float uruf = weightvalue - 85;
        float zakat = uruf * currentvalue;
        double totalzakat = zakat * 0.025;


            TextView et1 = (TextView) findViewById(R.id.output);
            et1.setText("Total Value:\n" + "RM "+ totalvalue);

            TextView et2 = (TextView) findViewById(R.id.output2);
            et2.setText("Zakat Payable\n" + "RM "+ zakat);

            if (totalzakat < 0) {
                totalzakat = 0;

                calculation = "Total Zakat:\n" + "RM "+ totalzakat;
                resulttext.setText(calculation);

            } else {

                calculation = "Total Zakat:\n" + "RM "+totalzakat;
                resulttext.setText(calculation);
            }

        }
    }
}

